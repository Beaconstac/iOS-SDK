//
//  Beaconstac.h
//  Beaconstac
//
//  Created by Sachin Vas on 06/11/17.
//  Copyright © 2017 MobStac. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Beaconstac.
FOUNDATION_EXPORT double BeaconstacVersionNumber;

//! Project version string for Beaconstac.
FOUNDATION_EXPORT const unsigned char BeaconstacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Beaconstac/PublicHeader.h>


